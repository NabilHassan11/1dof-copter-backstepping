clear;
clc;

%Motor Parameters
m_motor = 52e-3;                % Mass of motor [kg]
r_propeller = 0.15;             % Propeller radius [m]
J_motor = (1/2) * m_motor * r_propeller^2; % Motor's moment of inertia

R = 0.09;      % Resistance (Ohms)
L = 50e-6;    % Inductance (H)
Ke = 0.00434;    % Back-EMF constant (V-s/rad)
Kt = 0.00434;    % Torque constant (Nm/A)
B = 0.001;    % Damping coefficient (Nm-s/rad)


% System Parameters
m_rod = 0.198;                  % Mass of the rod [kg]
l_rod = 0.3;                    % Length of the rod [m]
J_rod = m_rod * l_rod^2;        % Rod's moment of inertia

J_total = J_rod + J_motor;      % Total inertia
g = 9.81;                       % Gravitational acceleration [m/s^2]

%Thrust Force Parameters
C_t = 1.732;                    % Thrust coefficient
P = 1.225;                      % Air density
r = 0.15;                       % Radius of Propeller
pitch = 0.1143;                 % Pitch of Propeller

%Air speed v = k * w where omega is the rotor speed
k = pitch/(2*pi);               % proportionality constant dependent on the propeller 

%Thrust Force (T) Relation to Rotor Speed
% T = 1/2 * Ct  * pi * P * r^2 * v^2


% k = 7.218e-8;                   % the proportionality constant k where F = k*RPM^2
% c = k*(2200)^2;

% Define nonlinear state-space dynamics
nonlinear_dynamics = @(t, x, w) [x(2);
    (l_rod * (1/2 * C_t  * pi * P * r^2 * k^2 * w^2) - l_rod * (0.5*m_rod + m_motor) * g * sin(x(1))) / J_total];

% Time vector
tspan = [0 10];

% Initial conditions
x0 = [pi/6; 0];  % Starting at a small angle with zero angular velocity

% Input force F(t), here we can define it as a function of time
w_func = @(t) 0;  % Example: constant force input over time

% Simulate using ODE solver
[t, x] = ode45(@(t, x) nonlinear_dynamics(t, x, w_func(t)), tspan, x0);

% Plot results
figure;
subplot(2,1,1);
plot(t, x(:,1));
ylabel('\theta (rad)');
title('Rod Angular Position');

subplot(2,1,2);
plot(t, x(:,2));
ylabel('\theta_{dot} (rad/sec)');
xlabel('Time (s)');
