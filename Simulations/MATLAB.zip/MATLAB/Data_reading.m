% Define the serial port and baud rate (use the correct COM port)
arduinoPort = 'COM11'; % Replace with your Arduino's COM port
baudRate = 9600;

% Create a serialport object
arduino = serialport(arduinoPort, baudRate);

% Set up the terminator (Arduino sends a newline at the end of each line)
configureTerminator(arduino, "LF");

% Parameters for real-time data collection
numSamples = 1000; % Total number of samples to store (adjust based on your needs)
data = zeros(numSamples, 3); % Preallocate [Time(s), Roll(deg), PWM(V)]
index = 1; % Index for storing data

% Set up the real-time plot
figure;
h1 = plot(data(:,1), data(:,2), 'r', 'DisplayName', 'Roll (deg)');
hold on;
h2 = plot(data(:,1), data(:,3), 'b', 'DisplayName', 'PWM (V)');
xlabel('Time (s)');
ylabel('Value');
legend show;
title('Real-Time Data from Arduino');
grid on;

disp('Reading data from Arduino... Press Ctrl+C to stop.');

try
    while true
        % Read a line of data from Arduino
        line = readline(arduino);
        
        % Split the line into numeric values
        values = str2double(strsplit(line, ','));
        
        % Check if the line contains valid data
        if numel(values) == 3
            % Store the data at the current index
            data(index, :) = values;
            
            % Update the plot
            set(h1, 'YData', data(:,2), 'XData', data(:,1)); % Update roll data
            set(h2, 'YData', data(:,3), 'XData', data(:,1)); % Update PWM data
            drawnow;
            
            % Increment the index, wrap around if needed (sliding window)
            index = index + 1;
            if index > numSamples
                index = 1; % Restart overwriting from the beginning
            end
        end
    end
catch
    disp('Stopped reading data.');
end

% Save the data to a CSV file (optional)
writematrix(data, 'arduino_data.csv');

% Close the serial port
delete(arduino);
