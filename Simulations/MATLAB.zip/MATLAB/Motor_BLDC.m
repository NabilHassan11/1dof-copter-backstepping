% Parameters

R = 0.09;      % Resistance (Ohms)
L = 50e-6;    % Inductance (H)
Ke = 0.00434;    % Back-EMF constant (V-s/rad)
Kt = 0.00434;    % Torque constant (Nm/A)
B = 0.001;    % Damping coefficient (Nm-s/rad)
J = 0.018405;   % Rotor inertia (kg-m^2)

% State-space matrices
A = [-R/L, -Ke/L; 
      Kt/J, -B/J];
B = [1/L, 0; 
     0, -1/J];
C = eye(2);  % Outputs: Current and Angular Velocity
D = zeros(2, 2); % No direct feedthrough

% Create state-space system
sys = ss(A, B, C, D);

% Simulation parameters
t = 0:0.001:2; % Time vector (0 to 2 seconds with 1 ms step)
V_input = 12;  % Applied voltage (V)
T_L_input = 0.01; % Load torque (Nm)

% Define input signals
V = V_input * ones(size(t)); % Constant voltage input
T_L = T_L_input * ones(size(t)); % Constant load torque input

% Combine inputs
u = [V; T_L];

% Initial conditions
x0 = [0; 0]; % Initial current and angular velocity

% Simulate the system
[y, t, x] = lsim(sys, u', t, x0);

% Plot results
figure;
subplot(3, 1, 1);
plot(t, x(:, 1));
grid on;
title('Motor Current');
xlabel('Time (s)');
ylabel('Current (A)');

subplot